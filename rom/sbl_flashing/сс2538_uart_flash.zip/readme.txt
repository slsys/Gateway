﻿2020-07-08

Прошиваем сс2538 через USB-UART в Windows.
(проверено на Windows 7 32bit + python 3.8.2)

Ахтунг!
Данный способ работает, только если в чипе есть прошивка с поддержкой SBL!
Чистый чип чистый (без прошивки) я не смог прошить этим способом, но по ссылках ниже есть информация об успешной прошивке. 


Внимательно читаем это: https://modkam.ru/?p=1112#comment-2999 
И это: https://mysku.ru/blog/aliexpress/79984.html
Там все разжевано.

Качаем прошивальщик: https://github.com/JelmerT/cc2538-bsl или используем тот, что в этом архиве (cc2538-bsl.py).
Качаем python: http://www.python.org/download
Устанавливаем. Я ставил в C:\Python.

Подтягиваем необходимые дополнения:
pip3 install pyserial
pip3 install intelhex

Патчим прошивку для активации бутлоадера по этой инструкции: https://modkam.ru/?p=1112#comment-2999 
Если в файле прошивки не активировать бутлоадер, следующая прошивка через UART будет невозможна!

------------------------------------
Ищем в конце файла прошивки строку
:0CFFD400FFFFFFEF000000000000200015
Ее нужно поменять на
:0CFFD400FFFFFFF700000000000020000D
------------------------------------


Подключаем cc2538 к USB-UART:
cc2538 - UART
   Vcc - 3.3v (!!если подать 5в, чип сдохнет!!!)
   PA1 - RX
   PA0 - TX
   GND - GND


Если в чипе есть прошивка с поддержкой SBL, то нужно активировать бутлоадер:

------------------------------------
Перед подачей питания на cc2538 нужно соединить с GND пины RST и PA7. 
После подачи питания сначала разомкнуть RST-GND, затем PA7-GND.

На оригинальном стике v3 установлена кнопка, замыкающая RST и GND. 

На модифицированном есть две кнопки, с ним все проще - подаете на чип питание, зажимаете 
кнопки RESET и FLASH, отпускаете RESET, затем отпускаете FLASH.
------------------------------------

Если чип чистый (без прошивки), бутлоадер активируется при подаче питания. В теории.


Прошиваем (укажите свой ком-порт):
python.exe cc2538-bsl.py -p COM3 -e -w -v MODKAMRU_V3_USB_with_SBL.hex 


Процесс выглядит примерно так:

------------------------------------
C:\Python>python.exe cc2538-bsl.py -p COM3 -e -w -v MODKAMRU_V3_USB_with_SBL.hex
Opening port COM3, baud 500000
Reading data from MODKAMRU_V3_USB_with_SBL.bin
Cannot auto-detect firmware filetype: Assuming .bin
Connecting to target...
CC2538 PG2.0: 512KB Flash, 32KB SRAM, CCFG at 0x0027FFD4
Primary IEEE Address: 00:12:4B:00:0E:0F:3A:10
    Performing mass erase
Erasing 524288 bytes starting at address 0x00200000
    Erase done
Writing 524256 bytes starting at address 0x00200000
Write 232 bytes at 0x0027FEF80
    Write done
Verifying by comparing CRC32 calculations.
    Verified (match: 0x66d84517)
------------------------------------


Питон может ругаться на синтаксис, но на работу не влияет.
------------------------------------
cc2538-bsl.py:971: SyntaxWarning: "is not" with a literal. Did you mean "!="?
  if int(value) % int(device.page_size) is not 0:
cc2538-bsl.py:976: SyntaxWarning: "is not" with a literal. Did you mean "!="?
  if int(value, 16) % int(device.page_size) is not 0:
------------------------------------
В архиве - поправленный файл, в котором нет таких сообщений.


------------------------------------
https://github.com/egony
https://t.me/Egony