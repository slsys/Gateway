#!/bin/bash

python3 bin/esptool.py erase_flash
